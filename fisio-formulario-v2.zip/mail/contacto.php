<?php
/**
 * contacto.php — manejador de formulario de contacto para sitios HTML estáticos
 * (probado para Hostinger, PHP 7.4 a 8.4, con mail() del propio hosting).
 *
 * COMPATIBLE con los formularios existentes: lee los campos name, email, phone y
 * message por POST. No hace falta tocar el HTML para que funcione. Lo opcional
 * (honeypot y control de tiempo) se activa solo si el formulario envía esos campos.
 *
 * PROTECCIONES
 *  1. Solo POST. Un GET se redirige a la web.
 *  2. Origen: solo se acepta un envío hecho desde los dominios de 'hosts'.
 *  3. Inyección de cabeceras: un salto de línea (o cualquier carácter de control)
 *     en nombre, correo o teléfono se RECHAZA, no se limpia: es un ataque.
 *     El nombre del visitante nunca va en una cabecera salvo codificado.
 *  4. Campos manipulados: name[]=x (arrays) se rechaza.
 *  5. Validación: obligatorios, longitudes, formato de correo y de teléfono.
 *  6. Honeypot (opcional, campo "website"): si viene relleno es un bot; se le
 *     responde como si todo fuera bien y no se envía nada.
 *  7. Tiempo mínimo (opcional, campo "_t" en milisegundos, lo pone tu JS).
 *  8. Spam de enlaces: más de 'max_links' URLs, o BBCode/HTML de enlaces, se
 *     descarta en silencio (respuesta de éxito, sin envío).
 *  9. Límite por IP: 'rate_max' envíos cada 'rate_window' segundos. Se guarda un
 *     HASH de la IP (no la IP) en el directorio temporal del sistema y caduca con
 *     la ventana. Si no se puede escribir, no bloquea (falla abierto).
 *     Solo cuentan los envíos que de verdad salen: un visitante que corrige un
 *     dato mal escrito no gasta intentos.
 *     Detrás de Cloudflare, REMOTE_ADDR es la IP del nodo de Cloudflare, que
 *     comparten miles de visitantes; por eso se usa CF-Connecting-IP, pero SOLO
 *     si la conexión llega de verdad desde un rango de Cloudflare (si no, esa
 *     cabecera la podría inventar cualquiera).
 * 10. Correo bien formado: UTF-8, asunto y remitente codificados, cuerpo en
 *     base64 (tildes, eñes y líneas largas llegan intactas), From de TU dominio
 *     (alineado con SPF/DKIM) y el correo del visitante solo en Reply-To.
 *
 * RESPUESTAS (las entiende tanto el JS de plantillas tipo "contact_me.js" con
 * jQuery como un fetch propio):
 *   200 enviado · 400 datos no válidos · 403 origen no permitido · 405 método ·
 *   429 demasiados envíos · 500 fallo al enviar.
 *   Si la petición pide JSON (Accept: application/json) responde JSON
 *   {ok, message, errors}; si no, texto. Si es un envío SIN JavaScript (el
 *   navegador navega), redirige a 'volver' con ?contacto=ok o ?contacto=error.
 *
 * REGISTRO: error_log() con el motivo de cada rechazo, SIN datos del visitante.
 *
 * OPCIONAL EN EL HTML
 *   Honeypot, dentro del <form>:
 *     <input type="text" name="website" tabindex="-1" autocomplete="off"
 *            style="position:absolute;left:-9999px" aria-hidden="true">
 *   OJO: si tu JS construye los datos a mano (p. ej. contact_me.js de Start
 *   Bootstrap: data: {name, phone, email, message}), añade también
 *   website: $("input[name=website]").val()  o el honeypot no llega al servidor.
 *
 *   Tiempo mínimo: un <input type="hidden" name="_t"> que tu JS rellene al
 *   enviar con los milisegundos transcurridos desde la carga de la página.
 *
 * RGPD: este script no guarda el mensaje ni ningún dato del visitante; solo
 * envía el correo. El hash de IP del límite de envíos no identifica a nadie y
 * se descarta al pasar la ventana. El texto legal del sitio debe mencionar el
 * formulario y al hosting como encargado del tratamiento.
 */

// ============================== CONFIGURACIÓN ==============================

$CONFIG = array(
    // Quién recibe los avisos.
    'to'          => 'focoves@yahoo.es',
    // Copia oculta opcional. '' para ninguna.
    'bcc'         => 'web@fisioterapiatorre.com',

    // Remitente. SIEMPRE una dirección de TU dominio, y que EXISTA como buzón:
    // recibe los rebotes. Nunca la del visitante (rompe SPF/DKIM = spam).
    'from'        => 'web@fisioterapiatorre.com',
    'from_name'   => 'Fisioterapia Torre (web)',

    'site_name'   => 'FisioterapiaTorre.com',
    'subject'     => 'FISIO CitaWeb',

    // Dominios desde los que se admite el envío. Sin "www.": se acepta solo.
    'hosts'       => array('fisioterapiatorre.com'),

    // A dónde volver en un envío sin JavaScript.
    'volver'      => '/',

    // Campos obligatorios (de entre name, email, phone, message).
    'obligatorios' => array('name', 'email', 'phone', 'message'),

    'min_seconds' => 3,    // tiempo mínimo, solo si el formulario envía _t
    'max_links'   => 2,    // enlaces permitidos en el mensaje
    'rate_max'    => 5,    // envíos por IP...
    'rate_window' => 600,  // ...en esta ventana, en segundos
);

$TEXTOS = array(
    'ok'          => 'Mensaje enviado. Te responderemos lo antes posible.',
    'datos'       => 'Revisa los datos del formulario.',
    'origen'      => 'No hemos podido procesar el envío.',
    'rapido'      => 'Has enviado el formulario demasiado rápido. Espera un momento y vuelve a intentarlo.',
    'limite'      => 'Has enviado varios mensajes seguidos. Espera unos minutos o llámanos.',
    'fallo'       => 'No hemos podido enviar tu mensaje. Inténtalo de nuevo o llámanos.',
    'name'        => 'Escribe tu nombre.',
    'email'       => 'Escribe un correo electrónico válido.',
    'phone'       => 'Escribe un teléfono válido: números, espacios y el signo +.',
    'message'     => 'Escribe tu mensaje (entre 5 y 3000 caracteres).',
    'linea'       => 'Este campo solo admite una línea, sin caracteres especiales.',
);

// ===========================================================================


/* ------------------------------ utilidades ------------------------------ */

function cf_len($s)
{
    return function_exists('mb_strlen') ? mb_strlen($s, 'UTF-8') : strlen($s);
}

/** Codifica un texto para una cabecera (asunto, nombre del remitente). */
function cf_cabecera($texto)
{
    if (preg_match('/^[\x20-\x7E]*$/', $texto)) {
        return $texto; // ASCII puro: no hace falta codificar
    }
    if (function_exists('mb_encode_mimeheader')) {
        return mb_encode_mimeheader($texto, 'UTF-8', 'B', "\r\n");
    }
    return '=?UTF-8?B?' . base64_encode($texto) . '?=';
}

/** ¿El envío viene del navegador navegando (sin JS) y no de un fetch/XHR? */
function cf_es_navegacion()
{
    $dest = isset($_SERVER['HTTP_SEC_FETCH_DEST']) ? $_SERVER['HTTP_SEC_FETCH_DEST'] : '';
    if ($dest !== '') {
        return $dest === 'document';
    }
    $xhr    = isset($_SERVER['HTTP_X_REQUESTED_WITH']);
    $accept = isset($_SERVER['HTTP_ACCEPT']) ? $_SERVER['HTTP_ACCEPT'] : '';
    return !$xhr && stripos($accept, 'text/html') !== false;
}

function cf_quiere_json()
{
    $accept = isset($_SERVER['HTTP_ACCEPT']) ? $_SERVER['HTTP_ACCEPT'] : '';
    return stripos($accept, 'application/json') !== false;
}

/** Responde y termina. */
function cf_responder($estado, $mensaje, $errores = array())
{
    global $CONFIG;

    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');

    if (cf_es_navegacion()) {
        $destino = $CONFIG['volver'];
        $destino .= (strpos($destino, '?') === false ? '?' : '&');
        $destino .= 'contacto=' . ($estado === 200 ? 'ok' : 'error');
        header('Location: ' . $destino, true, 303);
        exit;
    }

    http_response_code($estado);
    if (cf_quiere_json()) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(
            array('ok' => $estado === 200, 'message' => $mensaje, 'errors' => (object) $errores),
            JSON_UNESCAPED_UNICODE
        );
    } else {
        header('Content-Type: text/plain; charset=utf-8');
        echo $mensaje;
    }
    exit;
}

/** Registra el motivo de un rechazo, sin datos del visitante. */
function cf_log($motivo)
{
    error_log('contacto.php: ' . $motivo);
}

/** Host de una URL, en minúsculas y sin "www.". '' si no hay. */
function cf_host($url)
{
    $h = strtolower((string) parse_url($url, PHP_URL_HOST));
    return (strpos($h, 'www.') === 0) ? substr($h, 4) : $h;
}

/** ¿Está $ip dentro del rango CIDR $cidr? IPv4 e IPv6. */
function cf_ip_en_rango($ip, $cidr)
{
    list($red, $bits) = explode('/', $cidr);
    $a = @inet_pton($ip);
    $b = @inet_pton($red);
    if ($a === false || $b === false || strlen($a) !== strlen($b)) {
        return false;
    }
    $bits  = (int) $bits;
    $bytes = intdiv($bits, 8);
    if (substr($a, 0, $bytes) !== substr($b, 0, $bytes)) {
        return false;
    }
    $resto = $bits % 8;
    if ($resto === 0) {
        return true;
    }
    $mascara = chr((0xFF << (8 - $resto)) & 0xFF);
    return (($a[$bytes] & $mascara) === ($b[$bytes] & $mascara));
}

/**
 * IP real del visitante. Si la conexión viene de Cloudflare (proxy naranja),
 * la real está en CF-Connecting-IP. Rangos: https://www.cloudflare.com/ips/
 * (cambian muy de tarde en tarde; si Cloudflare añade uno, el efecto es solo
 * que ese tráfico se limita por IP de nodo, no que falle nada).
 */
function cf_ip_cliente()
{
    $remota = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
    $cf     = isset($_SERVER['HTTP_CF_CONNECTING_IP']) ? trim($_SERVER['HTTP_CF_CONNECTING_IP']) : '';
    if ($remota === '' || $cf === '' || filter_var($cf, FILTER_VALIDATE_IP) === false) {
        return $remota;
    }
    $rangos = array(
        '173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22',
        '141.101.64.0/18', '108.162.192.0/18', '190.93.240.0/20', '188.114.96.0/20',
        '197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
        '104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22',
        '2400:cb00::/32', '2606:4700::/32', '2803:f800::/32', '2405:b500::/32',
        '2405:8100::/32', '2a06:98c0::/29', '2c0f:f248::/32',
    );
    foreach ($rangos as $r) {
        if (cf_ip_en_rango($remota, $r)) {
            return $cf;
        }
    }
    return $remota;
}

/**
 * Límite de envíos por IP. Devuelve false si se ha superado.
 * Guarda un hash (no la IP) con las marcas de tiempo de la ventana actual.
 */
function cf_dentro_del_limite($ip, $max, $ventana)
{
    if ($ip === '' || $max <= 0) {
        return true;
    }
    $dir = sys_get_temp_dir();
    if (!is_dir($dir) || !is_writable($dir)) {
        return true; // falla abierto: sin límite antes que bloquear a clientes
    }
    $fichero = rtrim($dir, '/\\') . '/cf_' . substr(hash('sha256', $ip . '|' . __FILE__), 0, 32);
    $fp = @fopen($fichero, 'c+');
    if (!$fp) {
        return true;
    }
    $permitido = true;
    if (flock($fp, LOCK_EX)) {
        $ahora  = time();
        $marcas = json_decode((string) stream_get_contents($fp), true);
        $marcas = is_array($marcas) ? $marcas : array();
        $recientes = array();
        foreach ($marcas as $t) {
            if (is_int($t) && $t > $ahora - $ventana) {
                $recientes[] = $t;
            }
        }
        if (count($recientes) >= $max) {
            $permitido = false;
        } else {
            $recientes[] = $ahora;
        }
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($recientes));
        fflush($fp);
        flock($fp, LOCK_UN);
    }
    fclose($fp);
    return $permitido;
}


/* -------------------------------- flujo -------------------------------- */

// 1. Solo POST.
$metodo = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '';
if ($metodo !== 'POST') {
    if ($metodo === 'GET' || $metodo === 'HEAD') {
        header('Location: ' . $CONFIG['volver'], true, 303);
        exit;
    }
    header('Allow: POST');
    http_response_code(405);
    exit;
}

// 2. Origen. El navegador manda Origin en los POST; si no, se mira Referer.
//    Si no llega ninguno de los dos (privacidad extrema), se deja pasar: el
//    resto de protecciones siguen actuando.
$permitidos = array();
foreach ($CONFIG['hosts'] as $h) {
    $permitidos[] = cf_host('https://' . $h);
}
$origen = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
if ($origen === '' || $origen === 'null') {
    $origen = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
}
if ($origen !== '') {
    $oh = cf_host($origen);
    if (!in_array($oh, $permitidos, true)) {
        cf_log('403, origen no permitido: ' . $oh . ' (se esperaba ' . implode(', ', $permitidos) . ')');
        cf_responder(403, $TEXTOS['origen']);
    }
}

// 3. Los campos tienen que ser texto (name[]=x es manipulación).
$campos = array();
foreach (array('name', 'email', 'phone', 'message', 'website', '_t') as $k) {
    $v = isset($_POST[$k]) ? $_POST[$k] : '';
    if (!is_string($v)) {
        cf_log('400, campo con tipo no valido: ' . $k);
        cf_responder(400, $TEXTOS['datos']);
    }
    $campos[$k] = trim($v);
}

// 4. Honeypot: un humano no ve ese campo. Éxito falso, no se envía nada.
if ($campos['website'] !== '') {
    cf_log('honeypot relleno, envio descartado');
    cf_responder(200, $TEXTOS['ok']);
}

// 5. Tiempo mínimo, solo si el formulario lo manda.
if ($campos['_t'] !== '' && ctype_digit($campos['_t'])
    && (int) $campos['_t'] < (int) $CONFIG['min_seconds'] * 1000) {
    cf_log('400, envio demasiado rapido');
    cf_responder(400, $TEXTOS['rapido'], array('_t' => $TEXTOS['rapido']));
}

$errores = array();

// 6. INYECCIÓN DE CABECERAS. Nombre, correo y teléfono son de una línea:
//    cualquier carácter de control (\r, \n, \0, tabulador...) se rechaza.
foreach (array('name', 'email', 'phone') as $k) {
    if (preg_match('/[\x00-\x1F\x7F]/', $campos[$k])) {
        $errores[$k] = $TEXTOS['linea'];
    }
}
if (isset($errores['name']) || isset($errores['email']) || isset($errores['phone'])) {
    cf_log('400, caracteres de control en un campo de una linea');
    cf_responder(400, $TEXTOS['datos'], $errores);
}

// En el mensaje se permiten saltos de línea y tabuladores; el resto de
// caracteres de control se eliminan. Saltos normalizados a \n.
$mensaje = str_replace(array("\r\n", "\r"), "\n", $campos['message']);
$mensaje = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $mensaje);

// 7. Validación.
$obligatorio = array_flip($CONFIG['obligatorios']);

$n = cf_len($campos['name']);
if (($n === 0 && isset($obligatorio['name'])) || $n > 100) {
    $errores['name'] = $TEXTOS['name'];
}

if ($campos['email'] === '') {
    if (isset($obligatorio['email'])) {
        $errores['email'] = $TEXTOS['email'];
    }
} elseif (strlen($campos['email']) > 254 || !filter_var($campos['email'], FILTER_VALIDATE_EMAIL)) {
    $errores['email'] = $TEXTOS['email'];
}

if ($campos['phone'] === '') {
    if (isset($obligatorio['phone'])) {
        $errores['phone'] = $TEXTOS['phone'];
    }
} elseif (!preg_match('/^[0-9+().\-\s]{6,25}$/', $campos['phone'])
    || strlen(preg_replace('/\D/', '', $campos['phone'])) < 6) {
    $errores['phone'] = $TEXTOS['phone'];
}

$m = cf_len($mensaje);
if (($m === 0 && isset($obligatorio['message'])) || ($m > 0 && $m < 5) || $m > 3000) {
    $errores['message'] = $TEXTOS['message'];
}

if ($errores) {
    cf_log('400, validacion: ' . implode(', ', array_keys($errores)));
    cf_responder(400, $TEXTOS['datos'], $errores);
}

// 8. Spam de enlaces: éxito falso, sin envío.
$enlaces = preg_match_all('~(https?://|www\.)~i', $mensaje . ' ' . $campos['name']);
if ($enlaces > (int) $CONFIG['max_links'] || preg_match('~\[url|<a\s~i', $mensaje)) {
    cf_log('spam de enlaces (' . $enlaces . '), envio descartado');
    cf_responder(200, $TEXTOS['ok']);
}

// 9. Límite de envíos por IP. Va aquí, al final, para que solo cuenten los
//     envíos que de verdad salen (no los errores de validación ni los bots).
if (!cf_dentro_del_limite(cf_ip_cliente(), (int) $CONFIG['rate_max'], (int) $CONFIG['rate_window'])) {
    cf_log('429, limite de envios superado');
    cf_responder(429, $TEXTOS['limite']);
}

// 10. Componer y enviar.
date_default_timezone_set('Europe/Madrid');

$cuerpo = 'Nuevo mensaje desde el formulario de ' . $CONFIG['site_name'] . "\n\n"
    . 'Nombre:   ' . ($campos['name'] !== '' ? $campos['name'] : '(no indicado)') . "\n"
    . 'Correo:   ' . ($campos['email'] !== '' ? $campos['email'] : '(no indicado)') . "\n"
    . 'Teléfono: ' . ($campos['phone'] !== '' ? $campos['phone'] : '(no indicado)') . "\n\n"
    . "Mensaje:\n" . $mensaje . "\n\n"
    . "--\n"
    . ($campos['email'] !== ''
        ? "Responde a este correo para contestar a la persona.\n"
        : "No dejó correo: contesta por teléfono.\n")
    . 'Recibido el ' . date('d/m/Y \a \l\a\s H:i') . "\n";
$cuerpo = str_replace("\n", "\r\n", $cuerpo);

$asunto = cf_cabecera($CONFIG['subject'] . ': ' . ($campos['name'] !== '' ? $campos['name'] : 'sin nombre'));

$cabeceras = array(
    'From: ' . cf_cabecera($CONFIG['from_name']) . ' <' . $CONFIG['from'] . '>',
);
if ($campos['email'] !== '') {
    // Solo la dirección, ya validada. El nombre del visitante NO va aquí.
    $cabeceras[] = 'Reply-To: ' . $campos['email'];
}
if ($CONFIG['bcc'] !== '') {
    $cabeceras[] = 'Bcc: ' . $CONFIG['bcc'];
}
$cabeceras[] = 'MIME-Version: 1.0';
$cabeceras[] = 'Content-Type: text/plain; charset=UTF-8';
$cabeceras[] = 'Content-Transfer-Encoding: base64';

// -f fija el remitente del sobre en tu dominio: alinea SPF y recibe los rebotes.
$enviado = mail(
    $CONFIG['to'],
    $asunto,
    chunk_split(base64_encode($cuerpo), 76, "\r\n"),
    implode("\r\n", $cabeceras),
    '-f' . $CONFIG['from']
);

if (!$enviado) {
    cf_log('500, mail() devolvio false');
    cf_responder(500, $TEXTOS['fallo']);
}

cf_responder(200, $TEXTOS['ok']);
